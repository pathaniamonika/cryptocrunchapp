import React from "react";

const Market = () => {
  return (
    <div className="row">
    <div className="col-12 table-responsive mt-3">
      <table className="table cointable">
         <thead> 
            <tr>
               <th></th>
               <th>Coins Type</th>
               <th>Price</th>
               <th>Market Cap</th>
               <th>Update</th>
            </tr>
         </thead>
         <tbody>
            <tr>
               <td><img src="https://raw.githubusercontent.com/atomiclabs/cryptocurrency-icons/master/128/color/btc.png?raw=true" title="coin type"/></td>
               <td>Bitcoin BTC</td>
               <td>$ 3,878.506</td>
               <td>Market Cap: $ 68,204,785,420</td>
               <td>h <span className="greenfont">+ 0.16%</span> 24h <span className="greenfont">+0.35%</span> 7d <span className="redfont">+0.12%</span></td>
            </tr>
            <tr>
               <td><img src="https://raw.githubusercontent.com/atomiclabs/cryptocurrency-icons/master/128/color/eth.png?raw=true" title="coin type"/></td>
               <td>Bitcoin BTC</td>
               <td>$ 3,878.506</td>
               <td>Market Cap: $ 68,204,785,420</td>
               <td>h <span className="greenfont">+ 0.16%</span> 24h <span className="greenfont">+0.35%</span> 7d <span className="redfont">+0.12%</span></td>
            </tr>
            <tr>
               <td><img src="https://raw.githubusercontent.com/atomiclabs/cryptocurrency-icons/master/128/color/btc.png?raw=true" title="coin type"/></td>
               <td>Bitcoin BTC</td>
               <td>$ 3,878.506</td>
               <td>Market Cap: $ 68,204,785,420</td>
               <td>h <span className="greenfont">+ 0.16%</span> 24h <span className="greenfont">+0.35%</span> 7d <span className="redfont">+0.12%</span></td>
            </tr>
            <tr>
               <td><img src="https://raw.githubusercontent.com/atomiclabs/cryptocurrency-icons/master/128/color/eth.png?raw=true" title="coin type"/></td>
               <td>Bitcoin BTC</td>
               <td>$ 3,878.506</td>
               <td>Market Cap: $ 68,204,785,420</td>
               <td>h <span className="greenfont">+ 0.16%</span> 24h <span className="greenfont">+0.35%</span> 7d <span className="redfont">+0.12%</span></td>
            </tr>
            <tr>
               <td><img src="https://raw.githubusercontent.com/atomiclabs/cryptocurrency-icons/master/128/color/btc.png?raw=true" title="coin type"/></td>
               <td>Bitcoin BTC</td>
               <td>$ 3,878.506</td>
               <td>Market Cap: $ 68,204,785,420</td>
               <td>h <span className="greenfont">+ 0.16%</span> 24h <span className="greenfont">+0.35%</span> 7d <span className="redfont">+0.12%</span></td>
            </tr>
            <tr>
               <td><img src="https://raw.githubusercontent.com/atomiclabs/cryptocurrency-icons/master/128/color/btc.png?raw=true" title="coin type"/></td>
               <td>Bitcoin BTC</td>
               <td>$ 3,878.506</td>
               <td>Market Cap: $ 68,204,785,420</td>
               <td>h <span className="greenfont">+ 0.16%</span> 24h <span className="greenfont">+0.35%</span> 7d <span className="redfont">+0.12%</span></td>
            </tr>
            <tr>
               <td><img src="https://raw.githubusercontent.com/atomiclabs/cryptocurrency-icons/master/128/color/btc.png?raw=true" title="coin type"/></td>
               <td>Bitcoin BTC</td>
               <td>$ 3,878.506</td>
               <td>Market Cap: $ 68,204,785,420</td>
               <td>h <span className="greenfont">+ 0.16%</span> 24h <span className="greenfont">+0.35%</span> 7d <span className="redfont">+0.12%</span></td>
            </tr>
         </tbody>
      </table>
      </div>
      </div>
   )
}
export default Market;